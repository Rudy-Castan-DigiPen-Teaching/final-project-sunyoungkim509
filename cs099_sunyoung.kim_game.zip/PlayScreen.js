class PlayScreen {
  constructor() {
    
    this.score = 0;
    this.ding = new Ding();
    
  }
  
  Update(){
    
    
  }
    
    
  
  Draw(){
    
    this.ding.Draw();
    
    push();
    frameCount = 0;
    let Count = frameCount;
    let CountUp = Count - 4;
    frameRate(1);
    
    
    RED(width* 5/6, height * 13/24);
    BLUE(width/6, height * 13/24);
    GREEN(width/2, height/4);
    YELLOW(width/2, height * 5/6);
    
      if (CountUp > 0) {
        push();
        textAlign(CENTER);
        fill(0);
        textSize(25);
        stroke(0);
        strokeWeight(3);
        text("60/"+CountUp, 440, 25);
        pop();
        
        
      } else if (CountUp > 60) {
        CurrentScene = StopScene;
      }
    
    
      pop();
    
      push();
      noStroke();
      fill(260,150);
      rect(0,0,500,40);
      pop();
    
      
    
    }
  
  OnKeyPressed(){
    if(keyCode == 'd'){
          if(color === 'FireBrick'){
            Score = Score+1;
            color = random(colors);
          }
      }
  }

}