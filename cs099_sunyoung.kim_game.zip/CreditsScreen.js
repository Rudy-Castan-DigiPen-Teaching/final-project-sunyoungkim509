class CreditsScreen{
  constructor(){
    this.mainmenu = new Button(width * 1/5, height * 17/20, "Back");
  }
  
  Update(){
    if(this.mainmenu.DidClickButton()){
      CurrentScene = MainMenuScene;
    }
  }
  
  Draw(){
    
    DrawTitle("Credits");
    
    fill(0);
    textSize(18);
    text("Made by Sunyoung Kim", width/2, height/2);
    
    this.mainmenu.DrawButton();
    
  }
  
  OnKeyPressed(){}
  
}