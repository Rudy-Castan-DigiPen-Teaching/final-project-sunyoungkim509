let CurrentScene;

let MainMenuScene;
let CreditsScene;
let OptionsScene;
let playSence;
let standbyScene;

function setup()
{
  createCanvas(500, 500);
  MainMenuScene = new MainMenu();
  CreditsScene = new CreditsScreen();
  playScene = new PlayScreen();
  standbyScene = new StandBy();
    
  CurrentScene = MainMenuScene;
  
}

function draw() {
  background(220);
  
  CurrentScene.Update();
  CurrentScene.Draw();
  
}