class StandBy {
  constructor(){
    this.go = new Button(width/2, height * 3/5, "GO!");
    this.back = new Button(width/2, height * 4/5, "Back");
  }
  
  Update(){
    if(this.go.DidClickButton()) {
      CurrentScene = playScene;
    } else if (this.back.DidClickButton()){
      CurrentScene = MainMenuScene;
    }
  }
  
  Draw(){
    push();
    textAlign(CENTER);
    fill(0);
    textSize(25);
    stroke(0);
    strokeWeight(3);
    text("READY?", width/2, height/2);
    pop();
    
    this.go.DrawButton();
    this.back.DrawButton();
    
  }
  
  
}