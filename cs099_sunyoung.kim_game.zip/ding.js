class Ding {
  constructor(){
    
  }
  Update(){}
  
  Draw(){
    let color = 0;
    
    let colors = ['FireBrick','DeepSkyBlue','ForestGreen','Orange'];
let a = random(colors);

if ( a == 'FireBrick')
{
      color = 'FireBrick'
}
else if ( a == 'DeepSkyBlue')
{
      color = 'DeepSkyBlue'
}
else if ( a == 'ForestGreen')
{
      color = 'ForestGreen'
}
else if ( a == 'Orange')
{
      color = 'Orange'
}

console.log(color);
    
    fill(color);
    noStroke();
    circle(width/2, height * 13/24,20);
    
    
    if (keyCode == 'd'){
      if (color == 'FireBrick') {
        color = random(colors);
      }
    }
    
    if (keyCode == 'a') {
      if (color == 'DeepSkyBlue') {
        color = random(colors);
      }
    }
    
    if (keyCode == 'w') {
      if (color == 'ForestGreen') {
        color = random(colors);
      }
    }
    
    if (keyCode == 's') {
      if (color == 'Orange') {
        color = random(colors);
      }
    }
  
  }
}