class EmptyScene {
  constructor(){
  }
  
  Update(){}
  Draw(){}
  OnKeyPressed(){}
}