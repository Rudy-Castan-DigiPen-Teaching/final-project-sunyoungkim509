

function DrawTitle(label){
  
  push();
  textAlign(CENTER);
  fill(0);
  textSize(30);
  stroke(0);
  strokeWeight(2);
  text(label, width/2, 50);
  pop();
  
}

function BGI(){
  push();
  fill(128, 227, 118);
  noStroke();
  rect(0,0,500,500);
  pop();
  push();
  fill(38, 149, 56);
  noStroke();
  pop();
}

function RED(baseX, baseY) {
  push();
  noStroke();
  fill('FireBrick');
  square(baseX-45, baseY-45,90,10);
  pop();
}

function BLUE(baseX, baseY) {
  push();
  noStroke();
  fill('DeepSkyBlue');
  square(baseX-45, baseY-45,90,10);
  pop();
}

function GREEN(baseX, baseY) {
  push();
  noStroke();
  fill('ForestGreen');
  square(baseX-45, baseY-45,90,10);
  pop();
}

function YELLOW(baseX, baseY) {
  push();
  noStroke();
  fill('Orange');
  square(baseX-45, baseY-45,90,10);
  pop();
}