class MainMenu extends EmptyScene {
  constructor(){
    super();
    const x = width * 4/5;
    this.play = new Button(x, height * 13/20, "Play");
    this.description = new Button(x, height * 15/20, "Description")
    this.credits = new Button(x, height * 17/20, "Credits");
  }
  
  Update(){
    if(this.play.DidClickButton()){
      CurrentScene = standbyScene;
    } else if (this.credits.DidClickButton()) {
      CurrentScene = CreditsScene;
    } else if (this.description.DidClickButton()) {
      
    } 
    
    
  }
  
  Draw(){
    
    this.play.DrawButton();
    this.description.DrawButton();
    this.credits.DrawButton();
  }
  
}